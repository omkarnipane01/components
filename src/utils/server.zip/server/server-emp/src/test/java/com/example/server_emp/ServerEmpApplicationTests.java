package com.example.server_emp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerEmpApplicationTests {

	@Test
	void contextLoads() {
	}

}
