package com.example.server_emp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerEmpApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerEmpApplication.class, args);
	}

}
