
package com.example.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import  org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.User;
import com.example.service.UserService;

@RestController

@RequestMapping("/api/users")

public class UserController {
    // UserService userService = new UserService();
    // the above line can be written as shown below.
    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user){
    User savedUser =  userService.createUser(user);
    return  ResponseEntity.ok(savedUser);
    }

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers(){
        List<User> users= userService.getAllUsers();
        return  ResponseEntity.ok(users);
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
    Optional<User> user = userService.getUserById(id);
    return user.map(ResponseEntity::ok)
               .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUserById(@PathVariable Long id){
        userService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User updateUser){
        Optional<User> optionalUser = userService.getUserById(id);
        if (optionalUser.isPresent()) {
            User existingUser = optionalUser.get();
            existingUser.setName(updateUser.getName());
            existingUser.setPhone(updateUser.getPhone());
            existingUser.setEmail(updateUser.getEmail());
            existingUser.setSalary(updateUser.getSalary());
            existingUser.setDesignation(updateUser.getDesignation());
            existingUser.setProfile(updateUser.getProfile());
            existingUser.setLocation(updateUser.getLocation());
            existingUser.setStatus(updateUser.getStatus());
            
            User saved = userService.createUser(existingUser); // save() handles update too
            return ResponseEntity.ok(saved);
            
        }else{
            return  ResponseEntity.notFound().build();
        }
    }
}


// in UserService can we execute raw sql queries as some time we required searching users based on nam, email , contact number, etc