package com.example.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "emps")
public class User{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Auto-increment
    private Long id;
    @Column(nullable =false)
    private String name;
    private String  phone;
    private String salary;
    private String designation;
    @Column (nullable =false, unique= true)
    private String email;

    private String profile;
     private String location;
    private String status;
     
      public User(){

     }
     public User(String name,String  phone,String salary,String designation,String email,String profile,String location,String status){
       this.name = name;
    this.phone = phone;
    this.salary = salary;
    this.designation = designation;
    this.email = email;
    this.profile = profile;
    this.location = location;
    this.status = status;

     }
      public Long getId() {
        return id;
    }
    public void setId(Long id){
        this.id = id; 
    }
     public String getName(){
        return name;
     }
     public void setName(String name){
        this.name = name;
     }
      public String getPhone(){
        return phone;
     }
      public void setPhone(String phone){
        this.phone = phone;
     }
      public String getSalary(){
        return salary;
     }
     public void setSalary(String salary){
        this.salary = salary;
     }
      public String getDesignation(){
        return designation;
     }
     public void setDesignation(String designation){
        this.designation = designation;
     }
      public String getEmail(){
        return email;
     }
      public void setEmail(String email){
        this.email = email;
     }
      public String getProfile(){
        return profile;
     }

      public void setProfile(String profile){
        this.profile = profile;
     }
     public void setLocation(String location){
        this.location = location;
     }
      public String getLocation(){
        return location;
     }
    
     public void setStatus(String status){
        this.status = status;
     }
    public String getStatus(){
        return status;
    }
}